
public class MuchBetter {

	/**
	 *Chayse Summers
	 *CSC142 - Gandham
	 *January 16th, 2015
	 *Assignment 1 - #1.)
	 */
	
	// This program is to show how to print specific characters. I found it to be fairly easy.
	//I spent about ten minutes with this code. I chose to do it all on a single print line
	//in order have a little more fun with it.
	
	public static void main(String[] args) {
		System.out.println("A \"quoted\" String is\n\'much\' better if you learn\nthe rules of \"escape sequences.\"\nAlso, \"\" represents an empty String.\nDon\'t forget: use \\\" instead of \" !\n\'\' is not the same as \"");
		

	}

}
